Students of Watan is a variant of the game Settlers of Watan. 
